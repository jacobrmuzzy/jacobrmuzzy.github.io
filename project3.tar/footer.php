<!-- Start of included footer -->
			<div id="footer">
				<p>This site is part of a CSU <a href=https://www.cs.colostate.edu/~ct310/yr2016sp/> CT 310 </a> Course Project. Created By: Baradji Diallo and Jacob Muzzy </p>
			</div>
		</div>
	</body>
</html>
