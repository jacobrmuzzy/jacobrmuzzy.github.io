<!DOCTYPE html>
<html>
<meta name="Jacob Muzzy">
<link rel="stylesheet" type="text/css" href="style.css">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css">
<header>
	<div id= "top">
		<h1>
			J&GARAC - Contact us
		</h1>
	</div>
	<title>
		Contact us
	</title>
</header>
<body>
	<div id = "links">
		<nav>
			<a href="index.php">
				Home</a>

			<a href="aboutus.php">
				About us</a>

			<a href="availableanimals/index.php">
				Our Adoptable Animals</a>

			<a href="contactus.php">
				Contact us</a>

		</nav>
	
	</div>

</body>
