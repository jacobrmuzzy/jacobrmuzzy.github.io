<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="author" content="Baradji Diallo, Alexander Hennings" />
	<meta name="description" content=" fake description of the authors"/>
	<title> About Us </title>
	<link href="style.css" rel="stylesheet" type="text/css" />
	
</head>
<?php include 'header.php'; ?>

<div id="content">	
		<div id="main">
		<p>    Mixed Paw Rescue is a devoted Rescue service for mixed breed dogs created in February of 2016. Through the dedication and time of our leading members, Baradji Diallo and Jacob Muzzy, this Rescue has grown into an online community. In the coming months Mixed Paw Rescue is looking at a variety of new opportunities. Please check back soon for new options and ideas.<p>
		</div>


</div>

<?php include 'footer.php'; ?>




