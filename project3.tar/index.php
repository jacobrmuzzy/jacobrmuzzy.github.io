<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="author" content="Baradji Diallo, Alexander Hennings" />
	<meta name="description" content=" fake home page"/>
	<title> home </title>
	<link href="style.css" rel="stylesheet" type="text/css" />
	
</head>
<?php include 'header.php'; ?>
	<div id="content">	
		<div id="main">

			<p>WELCOME TO MIXED PAW'S RESCUE SITE</p>
			<p>Here at Mixed Paw Rescue we devote ourselves to finding kind and loving homes for a variety of mixed breed dogs. We believe mixed breed dogs have amazing and loving qualities which can be lost in purebred dogs. Mixed breed dogs tend to be milder in personality with less known health issues due to a wider genetic diversity.
To combat domestic violence against animals or humans each of our dogs have been tested and supervised around a variety of ages. Each dog has also been tested for common viruses and have been brought up to date on medical testing and current vaccinations.</p>
		</div>
	</div>




<?php include 'footer.php'; ?>



